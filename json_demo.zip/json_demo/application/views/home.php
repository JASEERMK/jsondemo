<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<head>

	<meta charset="utf-8">
	<title>JSON DEMO</title>

 
</head>
<body>
<div class="container mt-5">
  <h1 class="text-center">Upload JSON file</h1>
  <div class="col-sm-12 col-lg-4 mr-auto ml-auto border p-4">
  <?php echo form_open_multipart('home/upload/'); ?>
    <div class="form-group">
      <label><strong>Upload File</strong></label>
      <div class="custom-file">
        <input type="file" name="file" multiple class="custom-file-input form-control" accept="application/JSON" id="customFile">
       </div>
    </div>
    <div class="form-group">
      <input type="submit" name="submit" value="submit" id="submit" class="btn btn-block btn-dark">
    </div>
  </form>
</div>
 </body>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</html>
