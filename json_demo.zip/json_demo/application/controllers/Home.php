<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	function __construct() {
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('home');
	}
	public function upload(){
		$json =  file_get_contents($_FILES['file']['tmp_name']);
		$obj  = json_decode($json);
		echo '<pre>' . print_r($obj) . '</pre>';
	}
}
