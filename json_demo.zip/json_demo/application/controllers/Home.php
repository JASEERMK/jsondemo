<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	function __construct() {
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('home');
	}
	public function upload(){
		
		$json =  file_get_contents($_FILES['file']['tmp_name']);
		$data['result']  = json_decode($json,true);
		//print_r($data['result']);exit();
		$this->load->view('dynamic_form',$data);
	}
}
