<?php 
$page_titel = 'Role Form';
include 'template/header.php';
include 'template/navigation.php'; 


if ($details) {
	$edit_id = form_input(array('name' => 'edit_id', 'id' => 'edit_id', 'class' => 'form-control', 'placeholder' => '', 'type' => 'hidden', 'value' => $details[0]->id));
} else {
	$edit_id = '';
}
if ($details) {
	$val = $details[0]->role;
} else {
	$val = '';
}
$role = form_input(array('name' => 'role', 'required' => 'required', 'id' => 'role', 'class' => 'form-control', 'placeholder' => ' Name', 'value' => $val, 'type' => 'text'));
  
?>

<div id="wrapper">
	<div class="main-content">
		<div class="col-xs-12">
			<div class="box-content">
				<h4 class="box-title">Role Form</h4>
				<!-- /.box-title -->
				<?php echo form_open_multipart('home/dispatches/save', array('autocomplete' => 'off', 'id' => 'complaint_form'));
				echo $edit_id;
				?>
				<div class="row">
					<div class="col-md-7">

						<h5><b>Role Name</b></h5>
						<?php echo $role;?>
					</div>
					  <div class="col-md-7" style="padding-left: 10px">
                                        <h4 style="color: #000;font-weight: bold">Permissions</h4>


                                        <div class="card-body" style="padding-left: 0px">
                                            <div class="table-responsive">
                                                <table class="table table-bordered btn-" id="dataTable" width="100%" cellspacing="0">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 10px">Id</th>
                                                            <th>Permissions</th>
                                                            <th style="width: 130px">Select All <input type="checkbox" name="check_all" id="check_all" class="check_all " ></th>
                                                        </tr>
                                                    </thead>

                                                    <tbody>

                                                        <?php
                                                        $permissions = $this->cf->get_data('permission_list');
                                                        if ($permissions) {
                                                            foreach ($permissions as $value) {
                                                                 if ($details) {
                                                                    $permission = explode(",", $details[0]->permissions);
                                                                } else {
                                                                    $permission = '';
                                                                }

                                                                echo '<tr>
                                                       <td>' . $value->id . '</td>
                                                       <td>' . $value->permissions . '</td>

                                                        <td class = "text-center"><label><input type = "checkbox"';

                                                                if ($permission) {
                                                                    if (in_array($value->id, $permission)) {
                                                                        echo ' checked = "checked" ';
                                                                    }
                                                                }


                                                                echo 'name = "permissions[]" id = "lists_checkbox" value = ' . $value->id . ' class = "lists_checkbox " ></label></td>
                                                       </tr>';
                                                            }
                                                        }
                                                        ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>







                                    </div>
 

					<div class="col-md-12" style="padding-top: 20px;">	<?php	if(!$edit_id) { ?>
						<button type="submit" class="btn btn-primary btn-bordered waves-effect waves-light" style="margin-right:20px;">Create Role</button>
					<?php } else{ ?>
						<button type="submit" class="btn btn-bordered waves-effect waves-light">Update Role</button>
					<?php } ?>
				</div>

			</div>
			<!-- /.col-md-6 -->
		</div>
		<!-- /.row -->
	</div>
	</div>
			<!-- /.box-content -->
		</div>

 
	<?php include 'template/footer.php'; ?>
 